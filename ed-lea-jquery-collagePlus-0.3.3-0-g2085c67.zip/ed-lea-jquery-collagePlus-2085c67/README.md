##CollagePlus for jQuery

Create an image gallery like Google+ Albums or Flickr profile pages. 

Project home page: http://collageplus.edlea.com/


Example
-------
![Gallery Preview](https://raw.github.com/ed-lea/jquery-collagePlus/master/support/images/0.2.0-preview.png)

Try the [live example](http://collageplus.edlea.com/example.html "Live CollagePlus example") or play around with a [jsfiddle](http://jsfiddle.net/edlea/uZv3n/) version




For detailed usage instructions please visit http://collageplus.edlea.com/
